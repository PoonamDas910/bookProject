BookApp.controller("BookController", function ($scope) {
    $scope.bookArr = [
        { bookId: 101, bookName: 'C# in Depth', Author: 'Jon Skeet', ISBN: 1234567891, Price: 600, Description: 'C# in Depth is a book for those who are passionate about C#. It aims to be a bridge between the existing introductory books and the language specification.', bookImage: 'image/book1.jpg', Subject: 'Computer Science' },
        { bookId: 102, bookName: 'Angular in Action', Author: 'Jeremy Wilken', ISBN: 978654123, Price: 800, Description: 'Angular in Action teaches you everything you need to build production-ready Angular applications.', bookImage: 'image/book2.jpg', Subject: 'Computer Science' },  
        { bookId: 103, bookName: 'Vedic Mathematics', Author: 'P.Selvaraj', ISBN: 417285963, Price: 900, Description: ' The book comprises of chapters on algebra, geometry and vectors, calculus, series, differential equations, complex analysis, transforms, and numerical techniques.', bookImage: 'image/math3.jpg', Subject: 'Mathematics' },
        { bookId: 104, bookName: 'The Lord of Rings', Author: 'J.R.R.Tolkien', ISBN: 251436987, Price: 500, Description: 'The Lord of the Rings is an epic high fantasy novel written by J.R.R. Tolkien, which was later fitted as a trilogy. The story began as a sequel to Tolkien earlier fantasy book The Hobbit, and soon developed into a much larger story.', bookImage: 'image/nov1.jpg', Subject: 'Novel' },
        { bookId: 105, bookName: 'Quantum Physics', Author: 'Brad Olsson', ISBN: 545621238, Price: 1200, Description: 'The most compelling phenomena of quantum physics made easy the law of attraction and the theory of relativity', bookImage: 'image/phy3.jpg', Subject: 'Physics' },
        { bookId: 106, bookName: 'Harry Potter', Author: 'J.K.Rowling', ISBN: 917384265, Price: 750, Description: 'Harry Potter is a series of seven fantasy novels written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry.', bookImage: 'image/nov3.jpg', Subject: 'Novel' }
    ]


    $scope.showAddNewBookForm = false;
    $scope.showEditBookForm = false;
    $scope.showDescription = false;
    $scope.newBook = {};
    $scope.bId;
    $scope.bName;
    $scope.bAuthor;
    $scope.bIsbn;
    $scope.bPrice;
    $scope.bDescription;
    $scope.bImg;
    $scope.bSubject;
    $scope.bTableSubject;
    $scope.filteredBooks = [];
    $scope.EnableFiltered = false;
    $scope.errormessage = '';
    $scope.ClearData = function () {
        $scope.bId = '';
        $scope.bName = '';
        $scope.bAuthor = '';
        $scope.bIsbn = '';
        $scope.bPrice = '';
        $scope.bDescription = '';
        $scope.bImg = '';
        $scope.bSubject = '';
    }

    $scope.AddNewBook = function () {
        $scope.showAddNewBookForm = true;
        $scope.showEditBookForm = false;
        $scope.showDescription = false;
        if ($scope.bId != '') {
            $scope.ClearData();
        }
    }

    $scope.submitNewBook = function () {
        if ($scope.bSubject == '') {
            $scope.errormessage = "Mandatory to Select Subject";
        }
        else if ($scope.bId == '') {
            $scope.errormessage = "Please provide valid BookId";
        }
        else if ($scope.bName == '') {
            $scope.errormessage = "Please provide Book Name";
        }

        else if ($scope.bAuthor == '') {
            $scope.errormessage = "Please provide name of Book Author";
        }

        else if ($scope.bIsbn == '') {
            $scope.errormessage = "Please provide valid ISBN";
        }

        else if ($scope.bPrice == '') {
            $scope.errormessage = "Please provide Book Price";
        }

        else if ($scope.bImg == '') {
            $scope.errormessage = "Please provide valid Book Image";
        }

        else {
            $scope.newBook = {
                bookId: $scope.bId,
                bookName: $scope.bName,
                Author: $scope.bAuthor,
                ISBN: $scope.bIsbn,
                Price: $scope.bPrice,
                Description: $scope.bDescription,
                bookImage:"image/"+ $scope.bImg,
                Subject: $scope.bSubject
            }
            $scope.bookArr.push($scope.newBook);
            if ($scope.bTableSubject == $scope.bSubject) {
                $scope.filteredBooks.push($scope.newBook);
            }
            document.getElementById('img').value = '';
            $scope.ClearData();
            $scope.errormessage = '';
        }
    }

    $scope.cancelNewBook = function () {
        $scope.showAddNewBookForm = false;
        $scope.ClearData();
    }

    $scope.UploadImage = function (event) {
        console.log(event.target.files);
        $scope.bImg = event.target.files[0].name;
        console.log($scope.bImg);
    }

    $scope.EditBookDetails = function (obj) {
        $scope.showAddNewBookForm = false;
        $scope.showDescription = false;
        $scope.showEditBookForm = true;
        $scope.bPrice = obj.Price;
        $scope.bDescription = obj.Description;
        $scope.bName = obj.bookName;
        $scope.bId = obj.bookId;
    }

    $scope.UpdateEditBookDetails = function () {
        $scope.bookArr.forEach(book => {
            if (book.bookId == $scope.bId) {
                book.Price = $scope.bPrice;
                book.Description = $scope.bDescription;
            }
        })
        $scope.ClearData();
        console.log($scope.bookArr);
    }

    $scope.CancelEditBookDetails = function () {
        $scope.showEditBookForm = false;
        $scope.ClearData();
    }

    $scope.DeleteBookDetails = function (bookId) {
        $scope.showAddNewBookForm = false;
        if ($scope.showEditBookForm) {
            if ($scope.bId == bookId)
                $scope.showEditBookForm = false;
            else
                $scope.showEditBookForm = true;
        }
        if ($scope.showDescription) {
            if ($scope.bId == bookId)
                $scope.showDescription = false;
            else
                $scope.showDescription = true;
        }
        $scope.bookArr.forEach((book, index) => {
            if (book.bookId == bookId) {
                $scope.bookArr.splice(index, 1);
            }
        })
        $scope.filteredBooks.forEach((book, index) => {
            if (book.bookId == bookId) {
                $scope.filteredBooks.splice(index, 1);
            }
        })
    }
    $scope.ShowBookDescription = function (bookId) {
        $scope.showAddNewBookForm = false;
        $scope.showEditBookForm = false;
        $scope.showDescription = true;
        $scope.bookArr.forEach(book => {
            if (book.bookId == bookId) {
                $scope.bName = book.bookName;
                $scope.bDescription = book.Description;
            }
        })
    }

    $scope.CloseDescription = function () {
        $scope.showDescription = false;
        $scope.ClearData();
    }

    $scope.SelectSubjectFromDropDown = function () {
        console.log($scope.bSubject);
    }

    $scope.SelectSubjectToFilter = function () {
        $scope.filteredBooks = [];
        $scope.EnableFiltered = true;
        $scope.bookArr.forEach(book => {
            if ($scope.bTableSubject == book.Subject) {
                $scope.filteredBooks.push(book);
                console.log($scope.filteredBooks);
            }
        })
        if ($scope.bTableSubject == '')
            $scope.EnableFiltered = false;
    }
})



