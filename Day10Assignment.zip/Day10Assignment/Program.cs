﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day10Assignment
{
    class Book
    {
        //Id, Name, author, ISBN code, description of book, price, bookImage
        int bookId;
        string bookName;
        string bookAuthor;
        double isbn;
        double bookPrice;
        string description;

        public Book()
        {
        }
        public Book(int bookId, string bookName, string bookAuthor, double isbn, double bookPrice, string description)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.bookAuthor = bookAuthor;
            this.isbn = isbn;
            this.bookPrice = bookPrice;
            this.description = description;
        }
        public override string ToString()
        {
            return $"BookId : {bookId}; Book Name : {bookName}; Author : {bookAuthor}; ISBN Code : {isbn}; Price : {bookPrice} ";

        }
        public static void DisplayBook(List<Book> lst)
        {
            foreach (var item in lst)
            {
                Console.WriteLine(item);
            }
        }
        public static Book AddBook(List<Book> bookList)
        {
            Console.WriteLine("\nEnter the details of New Book  to Add:");
            int id =  bookList.Count+101;
            Console.WriteLine("Book Name: ");
            string bName = Console.ReadLine();
            Console.WriteLine("Author Name: ");
            string bAuthor = Console.ReadLine();
            Console.WriteLine("ISBN CODE: ");
            double bIsbn = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Book Price: ");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please provide Description of the book");
            string des = Console.ReadLine();

            Book book = new Book(id, bName, bAuthor, bIsbn, price, des);
            bookList.Add(book);
            return book;

        }

        public void ShowDescription(List<Book>bookList,int bid) {
         
            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].bookId == bid)
                {
                    Console.WriteLine("\nBook Name: "+bookList[i].bookName+"\t\t"+"Description: "+bookList[i].description);
                }
            }
        }
        public void DeleteBook(List<Book> bookList, int bid)
        {

            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].bookId == bid)
                {
                    bookList.RemoveAt(i);
                }
            }
        }

        public void DisplayBookDetails(List<Book> bookList, int bid)
        {
            
            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].bookId == bid)
                {
                    Console.WriteLine("\nDetails of Book \""+bookList[i].bookName+"\" having bookId "+bid+" is:\n");
                    Console.WriteLine( bookList[i].ToString() +"\t" + "Description: " + bookList[i].description);
                }
            }
        }

        public void EditBook(List<Book> bookList,int bid) {
          
                for (int i = 0; i < bookList.Count; i++)
                {
                    if (bookList[i].bookId == bid)
                    {
                        Console.WriteLine("Enter the updated Book Name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter the updated Price:");
                        double price = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the updated Description:");
                        string des = Console.ReadLine();

                        bookList[i].bookName = name;
                        bookList[i].bookPrice = price;
                        bookList[i].description = des;
                        Console.WriteLine("\nUpdated/edited Book details= " + bookList[i].ToString() + " Description: " + bookList[i].description);
                    }

                }
           

        }

    }
    internal class Program
    {
        public static void BoxingUnboxingExample() {
            int i = 100;
            object o = (object)i;  // implicit boxing
            Console.WriteLine("Boxing Done. Object Type=" + o);
            try
            {
                int j = (int)o;  //Unboxing the previously boxing object

                System.Console.WriteLine("Unboxing Done. Value Type=" + j);
            }
            catch (System.InvalidCastException e)
            {
                System.Console.WriteLine("{0} Error: Incorrect unboxing.", e.Message);
            }
        }

            static void Main()
        {
            //BoxingUnboxingExample();
            //======================================================================================================

            List<Book> bookList = new List<Book>() {
                new Book(101,"C# in Depth","Jon Skeet",1234567891,600,"C# in Depth is a book for those who are passionate about C#. It aims to be a bridge between the existing introductory books and the language specification"),
                new Book(102,"Angular in Action","Jeremy Wilken",978654123,800,"Angular in Action teaches you everything you need to build production-ready Angular applications."),
                new Book(103,"Database Design Solutions","Rod Stephens",159847236,400,"This book introduces you to database design,it Decribes how to structure the database so it gives good performance while minimizing the chance for error."),
            };
            Console.WriteLine("Original Book List:");
            Book.DisplayBook(bookList);

            Book bookObj = new Book();

            bool iterate = true;
            while (iterate)
            {
                try
                {
                    Console.Write("\nSelect from the Options below:");
                    Console.WriteLine("\n1.Edit Book");
                    Console.WriteLine("2.Delete Book");
                    Console.WriteLine("3.Add Book ");
                    Console.WriteLine("4.Show Description ");
                    Console.WriteLine("5.Display All Book");
                    Console.WriteLine("6.Display Particular Book Details");
                    Console.WriteLine("7.Exit ");

                    Console.Write("\nChoice=");
                    int choice = Convert.ToInt32(Console.ReadLine());//will give System.FormatException when entered input is other than int type

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("\nAll books Before Edit operation:");
                            Book.DisplayBook(bookList);
                            Console.WriteLine("\nEnter the Book Id to Edit The Book");
                            int Id=Convert.ToInt32(Console.ReadLine());
                            bookObj.EditBook(bookList,Id);
                            Console.WriteLine("\nAll Books After Edit operation:");
                            Book.DisplayBook(bookList);
                            break;

                        case 2:
                            Console.WriteLine("\nAll Books before Delete operation: ");
                            Book.DisplayBook(bookList);
                            Console.WriteLine("\nEnter the bookId to Delete it from the Book List:");
                            int bid = Convert.ToInt32(Console.ReadLine());
                            bookObj.DeleteBook(bookList, bid);
                            Console.WriteLine("\nBooks List after deleting a book:");
                            Book.DisplayBook(bookList);
                            break;

                        case 3:
                            bookObj= Book.AddBook(bookList);
                            Console.WriteLine("\nNew Book Details= "+bookObj.ToString());
                            Console.WriteLine("\nBook List After Adding New Book is:");
                            Book.DisplayBook(bookList);                            
                            break;

                        case 4:
                            Console.WriteLine("\nEnter the bookId to show its Description:");
                            int bid1= Convert.ToInt32(Console.ReadLine());
                            bookObj.ShowDescription(bookList, bid1);
                            break;

                        case 5:
                            Console.WriteLine("\nAll Book are:");
                            Book.DisplayBook(bookList);
                            break;
                        case 6:
                            Console.WriteLine("\nEnter the bookId to Display the Book Details:");
                            int bid2 = Convert.ToInt32(Console.ReadLine());
                            bookObj.DisplayBookDetails(bookList,bid2);
                            break;

                        case 7:
                            iterate = false;
                            break;

                        default:
                            Environment.Exit(default);
                            break;
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("  Entered Choice should only be a Natural Number.");
                    Console.WriteLine("  Error info:" + e.Message);
                }

            }
            Console.WriteLine("Exit Executed... Book Application Stopped.");



            Console.ReadLine();
        }
    }
}
